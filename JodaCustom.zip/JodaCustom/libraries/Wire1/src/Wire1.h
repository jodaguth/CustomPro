#ifndef TwoWire1_h
#define TwoWire1_h

#include <Wire.h>

extern TwoWire Wire1;

#endif

